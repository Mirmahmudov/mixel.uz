import React from 'react'

function Favorite_carts() {
  return (
    <div>Favorite_carts</div>
  )
}

export default Favorite_carts